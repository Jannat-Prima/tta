SET SERVEROUTPUT ON;

CREATE OR REPLACE TRIGGER update_product
AFTER UPDATE ON PRODUCT
FOR EACH ROW 

DECLARE 
   price_diff number; 
   msg varchar(100):= 'Product list have been updated !!!'; 
BEGIN 
	
    dbms_output.put_line(msg);
	price_diff := :NEW.price  - :OLD.price; 
	dbms_output.put_line('Product ID: ' || :OLD.product_id); 
	dbms_output.put_line('Product Name: ' || :OLD.product_name); 
        dbms_output.put_line('brand Name: ' || :OLD.brand_name); 
        dbms_output.put_line('Product price: ' || :OLD.price); 
         dbms_output.put_line('Product price: ' || :NEW.price);
         dbms_output.put_line('price difference: ' || price_diff); 


	
	
END; 
/

//update product set price=420 where product_id=4;