SET SERVEROUTPUT ON;

CREATE OR REPLACE TRIGGER delete_product
AFTER delete ON product
FOR EACH ROW 

DECLARE 
   msg varchar(100):= 'one product details have been deleted !!!'; 
BEGIN 

    dbms_output.put_line(msg);
	
	dbms_output.put_line('Product ID: ' || :OLD.product_id); 
	dbms_output.put_line('Product Name: ' || :OLD.product_name); 
        dbms_output.put_line('brand Name: ' || :OLD.brand_name); 
        dbms_output.put_line('Product price: ' || :OLD.price); 
	
 
	
	
	
END; 
/ 

 //delete product where product_id=8;