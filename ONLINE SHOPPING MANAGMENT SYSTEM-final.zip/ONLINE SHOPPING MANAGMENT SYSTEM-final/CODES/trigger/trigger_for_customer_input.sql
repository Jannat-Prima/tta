SET SERVEROUTPUT ON;

CREATE OR REPLACE TRIGGER insert_customer
AFTER INSERT ON customer
FOR EACH ROW 

DECLARE 
   msg varchar(100):= 'New customer details have been inserted !!!'; 
BEGIN 

    dbms_output.put_line(msg);
       dbms_output.put_line('NAME: ' || :NEW.customer_name); 
        dbms_output.put_line('adress: ' || :NEW.address); 
        
	
 
	
	
	
END; 
/ 