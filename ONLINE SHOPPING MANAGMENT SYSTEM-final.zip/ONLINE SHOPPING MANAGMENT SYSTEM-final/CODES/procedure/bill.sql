create or replace procedure create_bill(id IN customer.customer_id%type)
is
p_customer number(20);
p_product number (20);
p_basket number (20);
p_quantity number (20);
p_price product.price%type;
cost number;
cursor pb is
select customer_id,product_id,basket_id,quantity from basket_filled_by;
begin
 open pb();
  loop
     fetch pb into p_customer,p_product,p_basket,p_quantity;
     exit when pb%notfound;
    select price into p_price from product 
    inner join basket_filled_by on product.product_id=basket_filled_by.product_id 
    where basket_filled_by.customer_id=id ;
    cost:=p_quantity*p_price;
    
  end loop;
dbms_output.put_line('total cost is ' ||cost);
 close pb;
end create_bill;
/



set serveroutput on;
declare

begin	

create_bill(1);


	
end;
/


  