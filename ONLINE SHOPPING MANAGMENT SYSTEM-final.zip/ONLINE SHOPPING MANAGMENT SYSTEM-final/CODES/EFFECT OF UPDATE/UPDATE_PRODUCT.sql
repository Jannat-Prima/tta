create or replace procedure update_product(id IN product.product_id%type)
is
up_branch varchar2(100);

up1_product_id number(20);
up1_product_name varchar2(100);
up1_brand_name varchar2(100);
up1_product_details varchar2(100);
up1_review_id number(20);
up1_price number(20);
up1_branch varchar2(100);

up2_product_id number(20);
up2_product_name varchar2(100);
up2_brand_name varchar2(100);
up2_product_details varchar2(100);
up2_review_id number(20);
up2_price number(20);
up2_branch varchar2(100);

cursor up1 is
select product_id,product_name,brand_name,product_details,review_id,price,branch from product1@site_link1 where product_id=id;
cursor up2 is
select product_id,product_name,brand_name,product_details,review_id,price,branch from product2@site_link2 where product_id=id;

begin
  select branch into up_branch from product where product_id=id;
 open up1;
  loop
     fetch up1 into up1_product_id,up1_product_name,up1_brand_name,up1_product_details,up1_review_id,up1_price,up1_branch;
     exit when up1%notfound;
     
   end loop;
   
 open up2;
  loop
     fetch up2 into up2_product_id,up2_product_name,up2_brand_name,up2_product_details,up2_review_id,up2_price,up2_branch;
     exit when up2%notfound;
   end loop;
   
   if up_branch='azimpur'
     then
       insert into product1@site_link1 values(id,up1_product_name,up1_brand_name,up1_product_details,up1_review_id,up1_price,up1_branch);
       delete  product2@site_link2 where product_id=id;
       --delete product where product_id=id;
       --insert into product values(id,up1_product_name,up1_brand_name,up1_product_details,up1_review_id,up1_price,up1_branch);
   else 
       insert into product2@site_link2 values(id,up2_product_name,up2_brand_name,up2_product_details,up2_review_id,up2_price,up2_branch);
       delete  product1@site_link1 where product_id=id;
       --delete product where product_id=id;
       --insert into product values(id,up2_product_name,up2_brand_name,up2_product_details,up2_review_id,up2_price,up2_branch);
   
   
   end if;
   commit;
 close up1;
 close up2;
 
 end update_product;
/

set serveroutput on;
declare

begin	

update_product(1);

end;
/
