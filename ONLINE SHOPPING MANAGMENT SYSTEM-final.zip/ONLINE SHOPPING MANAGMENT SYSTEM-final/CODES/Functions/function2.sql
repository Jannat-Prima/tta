//how many times a user have used their basket-f2
CREATE OR REPLACE FUNCTION used_basket(id IN customer.customer_id%type)
RETURN number
IS
count_basket number;

BEGIN
select count(basket_id) into count_basket
from basket_filled_by where customer_id=id;
RETURN count_basket;
END used_basket;
/



BEGIN

DBMS_OUTPUT.PUT_LINE('max basket used by particular customer = '||used_basket(5));


END;
/