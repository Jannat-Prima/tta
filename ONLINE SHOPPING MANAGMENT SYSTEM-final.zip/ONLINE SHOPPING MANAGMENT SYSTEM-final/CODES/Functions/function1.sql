//top rated product of a following brand-f1
CREATE OR REPLACE FUNCTION which_brand(bname IN product.brand_name%type)
RETURN varchar
IS
pname varchar(30);

BEGIN
 select product_name into pname from product inner join review on review.review_id=product.review_id  where review_type='better' and product.brand_name=bname;
RETURN pname;
END which_brand;
/

SET SERVEROUTPUT ON;

BEGIN
DBMS_OUTPUT.PUT_LINE('top rated product'||which_brand('milani'));



END;
/