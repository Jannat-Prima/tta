//what payment type does a particular customer used-p2
CREATE OR REPLACE FUNCTION top_payment(cid in customer.customer_id%type)
RETURN varchar2
IS
count_payment varchar2(100);


BEGIN
select payment_name  into count_payment from payment 
where payment_id in 
(select count(payment_id) from payment where customer_id=cid);


RETURN count_payment;
END top_payment;
/

SET SERVEROUTPUT ON;

BEGIN

DBMS_OUTPUT.PUT_LINE('most used payment type by fellow customer= '||top_payment(5));


END;
/