//highest seller product of particular barnd-f3
CREATE OR REPLACE FUNCTION highest_seller(name in product.brand_name%type)
RETURN number
IS
count_product number;
top_product varchar2(100);

BEGIN
 select count(basket_filled_by.product_id) as p into count_product
from basket_filled_by 
inner join product on 
product.product_id=basket_filled_by.product_id 
where product.brand_name=name;


RETURN count_product;
END highest_seller;
/

SET SERVEROUTPUT ON;

BEGIN

DBMS_OUTPUT.PUT_LINE('highest sold by fellow brand= '||highest_seller('wetnwild'));



END;
/