create or replace package body order_package as
procedure create_bill(id IN customer.customer_id%type)
is
p_customer number(20);
p_product number (20);
p_basket number (20);
p_quantity number (20);
p_price product.price%type;
p_id number(20);
cost number;
cursor count_product is 
select product_id from basket_filled_by where customer_id =id;
cursor pb is
select customer_id,basket_id,quantity from basket_filled_by;
begin
open count_product();
loop
 fetch count_product into p_id;
     exit when count_product%notfound;
 open pb();
  loop
     fetch pb into p_customer,p_basket,p_quantity;
     exit when pb%notfound;
    select price into p_price from product 
    inner join basket_filled_by on product.product_id=basket_filled_by.product_id 
    where basket_filled_by.customer_id=id and basket_filled_by.product_id=p_id;
    cost:=p_quantity*p_price;
    end loop;
end loop;
dbms_output.put_line('total cost is ' ||cost);
insert into payment values('11','cash',p_customer,p_basket,cost);
 close pb;
close count_product;
end create_bill;
end order_package;
/