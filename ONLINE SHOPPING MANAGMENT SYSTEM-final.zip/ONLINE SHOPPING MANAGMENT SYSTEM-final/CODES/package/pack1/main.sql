set serveroutput on;
declare
begin
order_package.create_bill(4);
end;
/