set serveroutput on;

create or replace package order_package as
	
	procedure create_bill(id IN customer.customer_id%type);

	
end order_package;
/



