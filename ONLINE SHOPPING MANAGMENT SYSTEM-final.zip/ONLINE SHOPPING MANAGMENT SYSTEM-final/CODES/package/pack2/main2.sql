SET SERVEROUTPUT ON;

BEGIN
DBMS_OUTPUT.PUT_LINE('top rated product of the fellow milani =' ||which_brand('milani'));
DBMS_OUTPUT.PUT_LINE('max basket used by particular customer = '||used_basket(5));
DBMS_OUTPUT.PUT_LINE('highest sold by fellow brand= '||highest_seller('wetnwild'));
DBMS_OUTPUT.PUT_LINE('most used payment type by fellow customer= '||top_payment(5));


END;
/
