set serveroutput on;
create or replace package brand_infos as
	FUNCTION which_brand(bname IN product.brand_name%type);
        FUNCTION used_basket(id IN customer.customer_id%type);
        FUNCTION highest_seller(name in product.brand_name%type);
        FUNCTION top_payment(cid in customer.customer_id%type);
end brand_infos;
/
