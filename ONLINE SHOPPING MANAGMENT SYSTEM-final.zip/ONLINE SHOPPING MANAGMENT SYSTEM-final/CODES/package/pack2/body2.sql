create or replace package body brand_infos as
//top rated product of a following brand-f1
FUNCTION which_brand(bname IN product.brand_name%type)
RETURN varchar
IS
pname varchar(30);

BEGIN
 select product_name into pname from product inner join review on review.review_id=product.review_id  where review_type='better' and product.brand_name=bname;
RETURN pname;
END which_brand;


//how many times a user have used their basket-f2
 FUNCTION used_basket(id IN customer.customer_id%type)
RETURN number
IS
count_basket number;

BEGIN
select count(basket_id) into count_basket
from basket_filled_by where customer_id=id;
RETURN count_basket;
END used_basket;


//highest seller product of particular barnd-f3
 FUNCTION highest_seller(name in product.brand_name%type)
RETURN number
IS
count_product number;
top_product varchar2(100);

BEGIN
 select count(basket_filled_by.product_id) as p into count_product
from basket_filled_by 
inner join product on 
product.product_id=basket_filled_by.product_id 
where product.brand_name=name;


RETURN count_product;
END highest_seller;


//what payment type does a particular customer used-p2
 FUNCTION top_payment(cid in customer.customer_id%type)
RETURN varchar2
IS
count_payment varchar2(100);


BEGIN
select payment_name  into count_payment from payment 
where payment_id in 
(select count(payment_id) from payment where customer_id=cid);


RETURN count_payment;
END top_payment;
end brand_infos;
/