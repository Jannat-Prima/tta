drop table customer2 cascade constraints;
drop table product2 cascade constraints;

drop table customer_uses_basket2 cascade constraints;
drop table basket2 cascade constraints;

drop table customer_choose_from1 cascade constraints;
drop table basket_filled_by2 cascade constraints;

drop table review2 cascade constraints;
drop table payment2 cascade constraints;


create table customer2
(customer_id number(20) primary key,
customer_name varchar2(50),
address varchar2(50),
passward varchar2(20),
customer_type varchar2(50),
branch varchar2(100)
);

create table product2(product_id number(20) primary key,
product_name varchar2(100),
brand_name varchar2(100),
product_details varchar2(100),
review_id number(20),
price number(20),
branch varchar2(100)
);


create table customer_uses_basket2(customer_id number(20),
csb_date date,
quantity varchar2(20),
foreign key(customer_id) references customer(customer_id)
);






create table basket2(basket_id number(20) primary key,
product_id number(20),
customer_id number(20),
foreign key(product_id) references product(product_id),
foreign key(customer_id) references customer(customer_id)
);



create table customer_choose_from2(customer_id number(20),
product_id number(20),
foreign key(product_id) references product(product_id),
foreign key(customer_id) references customer(customer_id)
);





create table basket_filled_by2(customer_id number(20),
product_id number(20),
basket_id number(20),
quantity number(20),
foreign key(basket_id) references basket(basket_id),
foreign key(product_id) references product(product_id),
foreign key(customer_id) references customer(customer_id)
);







CREATE TABLE review2 (
 review_id number(20) NOT NULL,
review_type varchar2(100) NOT NULL,
 user_id number(20) NOT NULL
);

create table payment1(payment_id number(20) primary key,
payment_name varchar2(100),
customer_id number(20),
basket_id number(20),
bill varchar2(100),
foreign key(basket_id) references basket(basket_id),
foreign key(customer_id) references customer(customer_id)
);


commit;