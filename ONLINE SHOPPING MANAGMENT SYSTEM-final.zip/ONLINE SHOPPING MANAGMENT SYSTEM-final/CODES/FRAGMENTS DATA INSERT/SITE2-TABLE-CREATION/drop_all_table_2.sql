drop table customer2 cascade constraints;
drop table product2 cascade constraints;

drop table customer_uses_basket2 cascade constraints;
drop table basket2 cascade constraints;

drop table customer_choose_from2 cascade constraints;
drop table basket_filled_by2 cascade constraints;

drop table review2 cascade constraints;
drop table payment2 cascade constraints;