set serveroutput on;

declare

--for customer table

cursor c_cur1 is
select customer_id,customer_name,address,passward,customer_type,branch from customer
where branch = 'banani';
cursor c_cur2 is
select customer_id,customer_name,address,passward,customer_type,branch from customer
where branch = 'azimpur';

c_id number(20);
c_name varchar2(50);
c_address varchar2(50);
c_passward varchar2(20);
c_customer_type varchar2(50);
c_branch varchar2(100);

--for product table

cursor p_cur1 is
select product_id,product_name,brand_name,product_details,review_id ,price,branch from product
where branch = 'banani';
cursor p_cur2 is
select product_id,product_name,brand_name,product_details,review_id ,price,branch from product
where branch = 'azimpur';

p_id number(20);
p_name varchar2(100);
b_name varchar2(100);
p_details varchar2(100);
p_review_id number(20);
p_price number(20);
p_branch varchar2(100);

begin
	open c_cur1;
	loop
		fetch c_cur1 into c_id ,c_name,c_address ,c_passward ,c_customer_type ,c_branch;
		exit when c_cur1%notFound;

		insert into customer1@site_link1 values(c_id,c_name,c_address,c_passward,c_customer_type,c_branch);
	end loop;
	close c_cur1;

	open c_cur2;
	loop
		fetch c_cur2 into c_id ,c_name,c_address ,c_passward ,c_customer_type ,c_branch;
		exit when c_cur2%notFound;

		insert into customer2@site_link2 values(c_id,c_name,c_address,c_passward,c_customer_type,c_branch);
	end loop;
	close c_cur2;

	
        
        open p_cur1;
	loop
		fetch p_cur1 into p_id ,p_name,b_name,p_details,p_review_id,p_price,p_branch;
		exit when p_cur1%notFound;

		insert into product1@site_link1 values(p_id ,p_name,b_name,p_details,p_review_id,p_price,p_branch);
	end loop;
	close p_cur1;
        open p_cur2;
	loop
		fetch p_cur2 into p_id ,p_name,b_name,p_details,p_review_id,p_price,p_branch;
		exit when p_cur2%notFound;

		insert into product2@site_link2 values(p_id ,p_name,b_name,p_details,p_review_id,p_price,p_branch);
	end loop;
	close p_cur2;



end;
/
