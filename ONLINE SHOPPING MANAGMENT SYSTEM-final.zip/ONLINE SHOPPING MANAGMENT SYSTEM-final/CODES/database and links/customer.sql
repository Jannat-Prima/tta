drop table customer cascade constraints;
drop table customer_uses_basket cascade constraints;
drop table basket cascade constraints;
drop table product cascade constraints;
drop table customer_choose_from cascade constraints;
drop table basket_filled_by cascade constraints;
drop table admin cascade constraints;
drop table admin_added_product cascade constraints;
drop table review cascade constraints;
drop table payment cascade constraints;
drop table branch cascade constraints;


create table customer
(customer_id number(20) primary key,
customer_name varchar2(50),
address varchar2(50),
passward varchar2(20),
customer_type varchar2(50)
);
insert into customer values('1','arony','azimpur dhaka ','12345','regular');
insert into customer values('2','salman','mogbazar dhaka ','12345','general');
insert into customer values('3','asima','dhanmondi dhaka ','12345','regular');
insert into customer values('4','asif','kollayanpur dhaka ','12345','quick');
insert into customer values('5','alif','mirrur dhaka ','12345','regular');
insert into customer values('6','rodoshi','mdpur dhaka ','12345','regular');
insert into customer values('7','laboni','azimpur dhaka ','12345','regular');



create table customer_uses_basket(customer_id number(20),
csb_date date,
quantity varchar2(20),
foreign key(customer_id) references customer(customer_id)
);

insert into customer_uses_basket values('1','05-DEC-2017','2');
insert into customer_uses_basket values('2','07-apr-2017','2');
insert into customer_uses_basket values('3','11-nov-2017','2');
insert into customer_uses_basket values('3','15-mar-2017','2');
insert into customer_uses_basket values('3','21-jan-2017','2');
insert into customer_uses_basket values('5','28-feb-2017','2');
insert into customer_uses_basket values('7','3-jul-2017','2');



create table product(product_id number(20) primary key,
product_name varchar2(100),
brand_name varchar2(100),
product_details varchar2(100),
review_id number(20),
price number(20)
);

insert into product values('1','mac-lipstick','mac','uefiewfbiwebfi','1','220');
insert into product values('2','milani-lipstick','milani','hcehcisic','2','420');
insert into product values('3','milani-lipstick','milani','hcehcisic','3','420');
insert into product values('4','milani-lipstick','milani','Cosmetic','4','320');
insert into product values('5','wetandwild-lipstick','wetnwild','Cosmetic','7','520');
insert into product values('6','wetandwild-lipstick','wetandwild','Cosmetic','8','620');
insert into product values('7','dove-shampoo','dove','skin care','6','720');
insert into product values('8','dove-conditioner','dove','skincare','5','820');

create table basket(basket_id number(20) primary key,
product_id number(20),
customer_id number(20),
foreign key(product_id) references product(product_id),
foreign key(customer_id) references customer(customer_id)
);
--only 1st ta thik  serially jbe,bki gula ulta palta dilew prblm nai
insert into basket values('1','2','7');
insert into basket values('2','8','3');
insert into basket values('3','4','5');
insert into basket values('4','1','3');
insert into basket values('5','2','1');
insert into basket values('6','8','2');
insert into basket values('7','8','2');



/*
insert into product values('9','panteen-lipstick','Cosmetic','1','3','9','1','920');
insert into product values('10','panteen-incisnc','Cosmetic','2','4','10','4','920');
insert into product values('11','lux-lipstick','Cosmetic','1','5','11','1','820');
insert into product values('12','lux-incisnc','Cosmetic','2','6','12','4','720');
insert into product values('13','kam-lipstick','Cosmetic','1','1','1','1','620');
insert into product values('14','kam-incisnc','Cosmetic','2','2','2','4','520');
insert into product values('15','Almay-lipstick','Cosmetic','1','3','3','1','420');
insert into product values('16','Almay-incisnc','Cosmetic','2','4','4','4','320');
insert into product values('17','Bain de Soleil-lipstick','Cosmetic','1','5','5','1','220');
insert into product values('18','Bain de Soleil-incisnc','Cosmetic','2','6','6','4','120');
insert into product values('19','St. Tropez-lipstick','Cosmetic','1','1','7','1','120');
insert into product values('20','St. Tropez-incisnc','Cosmetic','2','2','8','4','220');
insert into product values('21','Biotherm-lipstick','Cosmetic','1','3','9','1','320');
insert into product values('22','Biotherm-incisnc','Cosmetic','2','4','10','4','420');
insert into product values('23','Laura Mercier-lipstick','Cosmetic','1','5','11','1','520');
insert into product values('24','Laura Mercier-incisnc','Cosmetic','2','6','12','4','620');*/



create table customer_choose_from(customer_id number(20),
product_id number(20),
foreign key(product_id) references product(product_id),
foreign key(customer_id) references customer(customer_id)
);

--ultapalta value dilei hbe
insert into customer_choose_from values('1','8');
insert into customer_choose_from values('2','8');
insert into customer_choose_from values('3','8');
insert into customer_choose_from values('4','7');
insert into customer_choose_from values('5','1');
insert into customer_choose_from values('5','1');



create table basket_filled_by(customer_id number(20),
product_id number(20),
basket_id number(20),
quantity number(20),
foreign key(basket_id) references basket(basket_id),
foreign key(product_id) references product(product_id),
foreign key(customer_id) references customer(customer_id)
);

--ultapalta value dilei hbe
insert into basket_filled_by values('1','1','1','2');
insert into basket_filled_by values('4','2','5','2');
insert into basket_filled_by values('5','5','5','2');
insert into basket_filled_by values('3','5','3','1');
insert into basket_filled_by values('5','4','4','2');
insert into basket_filled_by values('6','1','1','2');
insert into basket_filled_by values('7','5','6','2');


create table admin
(admin_id number(20) primary key,
admin_name varchar2(50),
passward varchar2(50)
);
--bki duijoner nam and id
insert into admin values('1','arony','el'); 
insert into admin values('2','alif','el'); 
insert into admin values('3','mahmud','el'); 


create table admin_added_product(product_id number(20),
quantity varchar2(100),
aap_date date,
foreign key(product_id) references product(product_id)
);

insert into admin_added_product values('1','10','10-jan-2013');
insert into admin_added_product values('2','12','10-mar-2013');
insert into admin_added_product values('3','14','10-DEC-2013');
insert into admin_added_product values('4','16','10-jan-2013');
insert into admin_added_product values('5','18','10-jan-2013');
insert into admin_added_product values('6','31','10-apr-2013');
insert into admin_added_product values('7','21','10-nov-2013');
insert into admin_added_product values('8','21','10-DEC-2013');
insert into admin_added_product values('1','41','10-DEC-2013');



CREATE TABLE review (
 review_id number(20) NOT NULL,
review_type varchar2(100) NOT NULL,
 user_id number(20) NOT NULL
);

INSERT INTO review VALUES
(1, 'good', 1);
INSERT INTO review VALUES
(2, 'averge', 1); 
INSERT INTO review VALUES
(3, 'avaerge', 1);  
INSERT INTO review VALUES
(4, 'better', 4);

INSERT INTO review VALUES
(5, 'bad', 5);
INSERT INTO review VALUES
(6, 'bad', 5);
INSERT INTO review VALUES
(7, 'normal', 7);

INSERT INTO review VALUES
(8, 'normal', 5);


create table payment(payment_id number(20) primary key,
payment_name varchar2(100),
customer_id number(20),
basket_id number(20),
bill varchar2(100),
foreign key(basket_id) references basket(basket_id),
foreign key(customer_id) references customer(customer_id)
);

INSERT INTO payment VALUES
(1, 'cash', 1, 1,'4200');


INSERT INTO payment VALUES(2, 'p.o.', 2, 2,'5200'),


INSERT INTO payment VALUES(3, 'bikash', 3, 3,'2100');

INSERT INTO payment VALUES(4, 'bikash', 4, 4,'2300');
INSERT INTO payment VALUES(5, 'cash', 5, 5,'230');
INSERT INTO payment VALUES(6, 'p.o.', 5, 6,'760');


INSERT INTO payment VALUES(7, 'bikash', 7, 7,'1100');
INSERT INTO payment VALUES(8, 'cash', 5, 4,'200');
INSERT INTO payment VALUES(9, 'cash', 5, 4,'1000');
INSERT INTO payment VALUES(10, 'cash', 5, 4,'2340');


create table branch(branch_id number(20) primary key,
branch_name varchar2(100),
product_id number(20),
admin_id number (20),
foreign key(product_id) references product(product_id),
foreign key(admin_id) references admin(admin_id)
);
insert into branch values('1','azimpur','1','1');
insert into branch values('2','mirpur','2','1');
insert into branch values('3','banani','3','1');

alter table customer add branch varchar2(100);
update customer set branch ='banani' where customer_id between 1 and 4;
update customer set branch ='azimpur' where customer_id between 5 and 7;
alter table product add branch varchar2(100);
update product set branch ='banani' where product_id between 1 and 4;
update product set branch ='azimpur' where product_id between 5 and 7;



commit;