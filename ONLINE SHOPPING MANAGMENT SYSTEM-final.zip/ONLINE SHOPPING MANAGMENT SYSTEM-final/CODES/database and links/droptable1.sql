drop table customer1 cascade constraints;
drop table product1 cascade constraints;

drop table customer_uses_basket1 cascade constraints;
drop table basket1 cascade constraints;

drop table customer_choose_from1 cascade constraints;
drop table basket_filled_by1 cascade constraints;

drop table review1 cascade constraints;
drop table payment1 cascade constraints;